#include <opencv2/opencv.hpp>
#include <iostream>

#include <vector>
#include <opencv2/core/core.hpp>

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc.hpp>

#include "../include/morphology.hpp"

using namespace cv;
using namespace std;


Point findLargestWhitePart(const Mat& binary) {
    Mat visited = Mat::zeros(binary.size(), CV_8U);
    Point largestCenter;
    int maxArea = 0;

    for (int y = 0; y < binary.rows; y++) {
        for (int x = 0; x < binary.cols; x++) {
            if (binary.at<uchar>(y, x) == 255 && visited.at<uchar>(y, x) == 0) {
                int area = 0;
                int sumX = 0, sumY = 0;
                queue<Point> q;
                q.push(Point(x, y));
                visited.at<uchar>(y, x) = 1;

                while (!q.empty()) {
                    Point p = q.front();
                    q.pop();
                    area++;
                    sumX += p.x;
                    sumY += p.y;

                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dx = -1; dx <= 1; dx++) {
                            int nx = p.x + dx;
                            int ny = p.y + dy;
                            if (nx >= 0 && nx < binary.cols && ny >= 0 && ny < binary.rows &&
                                binary.at<uchar>(ny, nx) == 255 && visited.at<uchar>(ny, nx) == 0) {
                                q.push(Point(nx, ny));
                                visited.at<uchar>(ny, nx) = 1;
                            }
                        }
                    }
                }

                if (area > maxArea) {
                    maxArea = area;
                    largestCenter = Point(sumX / area, sumY / area);
                }
            }
        }
    }

    return largestCenter;
}

Point findSmallDot(const Mat& binary) {
    for (int y = 0; y < binary.rows; y++) {
        for (int x = 0; x < binary.cols; x++) {
            if (binary.at<uchar>(y, x) == 255) {
                return Point(x, y);
            }
        }
    }
    return Point(-1, -1); // In case no dot is found
}




int main(int argc, char **argv)
{
	if ( argc != 2 )	
    {
        cout <<"usage: ./output <Image_Path>\n";
        return -1;
    }

	// Reading the Image
	Mat source_image = imread(argv[1], IMREAD_GRAYSCALE);
	
	
	// Check if the image is created successfully or not
	if (!source_image.data)
	{
		cout << "Could not open or find the image\n";
		return 0;
	}

	// creating container for output image according to size and type of source image
	Mat output_image{source_image.size(), source_image.type()};
	
	// Applying erosion on source image
	int kernel_size = 3;
	output_image = erosion(source_image, output_image, kernel_size);

	namedWindow("source", WINDOW_NORMAL);
	imshow("source", source_image);

	namedWindow("output", WINDOW_NORMAL);
	imshow("output", output_image);


	// Find the largest white part
    Point largestWhitePart = findLargestWhitePart(output_image);

    // Find the small dot
    Point smallDot = findSmallDot(output_image);

	

    // Output the results
    cout << "Small dot at: (" << smallDot.x << ", " << smallDot.y << ") will be set to (0,0)" << endl;
    cout << "Largest white part at: (" << largestWhitePart.x << ", " << largestWhitePart.y << ")" << endl;

	float Y = largestWhitePart.y - smallDot.y;
	float X = largestWhitePart.x - smallDot.x;
	double slope = Y / X ;

	if ( slope < 0.00 &&  slope >= -1.00){
		cout <<"Comet is in South West direction"<<endl;
	}

	if ( slope < 1.00 &&  slope >= 0.00){
		cout <<"Comet is in North West direction"<<endl;
	}

	if ( slope < -1.00 && slope > -3.00){
	     cout <<"Comet is in North East direction"<<endl;		
	}

	if ( slope < 2.00 && slope >= 1.00){
	     cout <<"Comet is in South East direction"<<endl;		
	}	
	
	waitKey();

	return 0;
}

